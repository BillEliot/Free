#include <ntddk.h>
#include <windef.h>

BYTE *ObOpObjByP_OpenProcess = NULL,*pJmp_OpenProcess= NULL,*pTPHook_OpenProcess = NULL;
BYTE *ObOpObjByP_OpenThread = NULL,*pJmp_OpenThread= NULL,*pTPHook_OpenThread = NULL;

BYTE *pHook_OpenProcess = NULL;
BYTE *pHook_OpenThread = NULL;
//////////////////////////////////////////////////////////////////////////////
void UnLoadDriver(PDRIVER_OBJECT pDriverObject);
/////////////////////////////////////////////////////////////////
ULONG GetFunAddress(PCWSTR FunName);
ULONG GetCurAddress(ULONG uIndex);
void WPOFF();
void WPOON();
/////////////////////////////////////////////////////////////////
void MyOpenProcess();
NTSTATUS InstallNtOpenProcessHook();
/////////////////////////////////////////////////////////////////
void MyOpenThread();
NTSTATUS InstallNtOpenThreadHook();
/////////////////////////////////////////////////////////////////
NTSTATUS InstallReadVirtualMemoryHook();
NTSTATUS InstallWriteVirtualMemoryHook();
//////////////////////////////////////////////////////////////////////////////
//����SSDT
typedef struct _SYSTEM_SERVICE_TABLE
{
	PVOID ServiceTableBase;
	PULONG ServiceCounterTableBase;
	ULONG NumberOfService;
	ULONG ParamTableBase;
}*PSYSTEM_SERVICE_TABLE;
extern "C" PSYSTEM_SERVICE_TABLE KeServiceDescriptorTable;
//////////////////////////////////////////////////////////////////////////////