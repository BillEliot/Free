#include "Driver.h"

/*******************************************
Name:GetFunAddress(PCWSTR FunName)
Description:Get Function Address
*******************************************/
ULONG GetFunAddress(PCWSTR FunName)
{
	UNICODE_STRING UFunName;

	RtlInitUnicodeString(&UFunName,FunName);
	return (ULONG)MmGetSystemRoutineAddress(&UFunName);
}
/*******************************************
Name:GetCurAddress(PCWSTR FunName)
Description:Get FunctionCurrent Address
*******************************************/
ULONG GetCurAddress(ULONG uIndex)
{
	ULONG uAddress = 0;
	__asm
	{
		push ebx
		push eax
		mov ebx,KeServiceDescriptorTable
		mov ebx,[ebx]
		mov eax,uIndex
		shl eax,0x2
		add ebx,eax
		mov ebx,[ebx]
		mov uAddress,ebx
		pop eax
		pop ebx
	}
	return uAddress;
}
/*******************************************
Name:WPOFF()
Description:Delete CR0
*******************************************/
void WPOFF()
{
	__asm
	{
		cli
			mov eax,cr0
			and eax,not 10000h
			mov cr0,eax
	}
}
/*******************************************
Name:WPON()
Description:Release CR0
*******************************************/
void WPON()
{
	__asm
	{
		mov eax,cr0
			or eax,10000h
			mov cr0,eax
			sti
	}
}
//////////////////////////////////////////////////////////////////////////////
/*******************************************
Name:MyOpenProcess
Description:MyOpenProcess
*******************************************/
_declspec(naked) void MyOpenProcess()
{
	PEPROCESS PP;
	ANSI_STRING strCurProcess,strDesProcess;

	PP = IoGetCurrentProcess();
	RtlInitAnsiString(&strCurProcess,(PCSZ)((ULONG)PP + 0x174));
	RtlInitAnsiString(&strDesProcess,"QQSpeed_loader.exe");

	__asm
	{
		push dword ptr [ebp-0x38]
		push dword ptr [ebp-0x24]
	}
	if(RtlCompareString(&strCurProcess,&strDesProcess,true) == 0)
	{
		//��Ϸ���̷���,��תTPHook��NtOpenProcess
		__asm
		{
			jmp pTPHook_OpenProcess
		}
	}
	//�������̷���,��ת����ObOpenObjectByPointer
	else
	{
		__asm
		{
			call ObOpObjByP_OpenProcess
			jmp pJmp_OpenProcess
		}
	}
}
/*****************************************
Name:InstallNtOpenProcessHook()
Description:Install NtOpenProcess Hook
******************************************/
NTSTATUS InstallNtOpenProcessHook()
{
	BYTE bHook[6] = {0xE9,0x0,0x0,0x0,0x0,0x90};
	//��ȡԭ��NtOpenProcess��ObOpenObjectByPointer��ַ
	BYTE* pNtOpenProcess = (BYTE*)GetFunAddress(L"NtOpenProcess");
	ObOpObjByP_OpenProcess = (BYTE*)GetFunAddress(L"ObOpenObjectByPointer");
	//�����������ȡ��ַ(push dword ptr [ebp-38])
	pHook_OpenProcess = pNtOpenProcess;
	while(true)
	{
		if(*pHook_OpenProcess == 0xFF && 
			*(pHook_OpenProcess + 1) == 0x75 &&
			*(pHook_OpenProcess + 2) == 0xC8 &&
			*(pHook_OpenProcess + 3) == 0xFF &&
			*(pHook_OpenProcess + 4) == 0x75 &&
			*(pHook_OpenProcess + 5) == 0xDC)
		{
			break;
		}

		pHook_OpenProcess ++;
	}
	//������ת��ַ(mov)
	pJmp_OpenProcess = pHook_OpenProcess + 0xB;
	pTPHook_OpenProcess = pHook_OpenProcess + 0x6;
	*(ULONG*)(bHook + 1) = (ULONG)MyOpenProcess - ((ULONG)pHook_OpenProcess + 5);
	//��װ����
	KIRQL kir;

	WPOFF();
	kir = KeRaiseIrqlToDpcLevel();
	RtlCopyMemory(pHook_OpenProcess,bHook,6);
	KeLowerIrql(kir);
	WPON();

	return STATUS_SUCCESS;
}
/*****************************************
Name:UnInstallNtOpenProcessHook()
Description:UnInstall NtOpenProcess Hook
******************************************/
void UnInstallNtOpenProcessHook()
{
	KIRQL kir;
	BYTE bRelease[6] = {0xFF,0x75,0xC8,0xFF,0x75,0xDC};

	WPOFF();
	kir = KeRaiseIrqlToDpcLevel();
	RtlCopyMemory(pHook_OpenProcess,bRelease,6);
	KeLowerIrql(kir);
	WPON();
}
////////////////////////////////////////////////////////////////////////////////
/*******************************************
Name:MyOpenThread
Description:MyOpenThread
*******************************************/
_declspec(naked) void MyOpenThread()
{	
	PEPROCESS PP;
	ANSI_STRING strCurProcess,strDesProcess;

	PP = IoGetCurrentProcess();
	RtlInitAnsiString(&strCurProcess,(PCSZ)((ULONG)PP + 0x174));
	RtlInitAnsiString(&strDesProcess,"QQSpeed_loader.exe");

	__asm
	{
	push dword ptr [ebp-0x34]
	push dword ptr [ebp-0x20]
	}
	if(RtlCompareString(&strCurProcess,&strDesProcess,true) == 0)
	{
		__asm
		{
			jmp pTPHook_OpenThread
		}
	}
	else
	{
		__asm
		{
			call ObOpObjByP_OpenThread
			jmp pJmp_OpenThread
		}
	}
}
/*****************************************
Name:InstallNtOpenThreadHook()
Description:Install NtOpenThread Hook
******************************************/
NTSTATUS InstallNtOpenThreadHook()
{
	BYTE *pNtOpenThread= NULL;
	BYTE bHook[6] = {0xE9,0x0,0x0,0x0,0x0,0x90};

	pNtOpenThread = (BYTE*)GetFunAddress(L"NtOpenThread");
	ObOpObjByP_OpenThread = (BYTE*)GetFunAddress(L"ObOpenObjectByPointer");
	//����������
	pHook_OpenThread = pNtOpenThread;
	while(true)
	{
		if(*pHook_OpenThread == 0xFF &&
			*(pHook_OpenThread + 1) == 0x75 &&
			*(pHook_OpenThread + 2) == 0xCC &&
			*(pHook_OpenThread + 3) == 0xFF &&
			*(pHook_OpenThread + 4) == 0x75 &&
			*(pHook_OpenThread + 5) == 0xE0 )
		{
			break ;
		}
		pHook_OpenThread ++;
	}
	//������ת��ַ
	pJmp_OpenThread = pHook_OpenThread + 0xB;
	pTPHook_OpenThread = pHook_OpenThread + 0x6;
	*(ULONG*)(bHook + 1) = (ULONG)MyOpenThread - ((ULONG)pHook_OpenThread + 5);
	//��װ����
	KIRQL kir;

	WPOFF();
	kir = KeRaiseIrqlToDpcLevel();
	RtlCopyMemory(pHook_OpenThread,bHook,6);
	KeLowerIrql(kir);
	WPON();

	return STATUS_SUCCESS;
}
/*****************************************
Name:UnInstallNtOpenThreadHook()
Description:UnInstall NtOpenThread Hook
******************************************/
NTSTATUS UnInstallNtOpenThreadHook()
{
	KIRQL kir;
	BYTE bRelease[6] = {0xFF,0x75,0xCC,0xFF,0x75,0xE0};

	WPOFF();
	kir = KeRaiseIrqlToDpcLevel();
	RtlCopyMemory(pHook_OpenThread,bRelease,6);
	KeLowerIrql(kir);
	WPON();
}
////////////////////////////////////////////////////////////////////////////////
 /*****************************************
 Name:InstallReadVirtualMemoryHook()
 Description:Install NtReadVirtualMemory Hook
 ******************************************/
 NTSTATUS InstallReadVirtualMemoryHook()
 {
 	//ReadVirtualMemory����û�е���,��SSDT����ȡĿ���ַ
 	BYTE bPush_1[2] = {0x6A,0x1C};
 	BYTE bPush_2[5] = {0x68,0x90,0xA7,0x4F,0x80};
 	KIRQL kir;
 
 	ULONG uAddress = GetCurAddress(0xBA);
 	WPOFF();
 	kir = KeRaiseIrqlToDpcLevel();
 	RtlCopyMemory((BYTE*)uAddress,bPush_1,2);
 	RtlCopyMemory((BYTE*)(uAddress + 2),bPush_2,5);
 	KeLowerIrql(kir);
 	WPON();
 
 	return STATUS_SUCCESS;
 }
/*****************************************
Name:InstallWriteVirtualMemoryHook()
Description:Install NtWriteVirtualMemory Hook
******************************************/
NTSTATUS InstallWriteVirtualMemoryHook()
{
	//WriteVirtualMemory����û�е���,��SSDT����ȡĿ���ַ
	BYTE bPush_1[2] = {0x6A,0x1C};
	BYTE bPush_2[5] = {0x80,0x4F,0xA7,0xA7,0xA8};
	KIRQL kir;

	ULONG uAddress = GetCurAddress(0x115);
	WPOFF();
	kir = KeRaiseIrqlToDpcLevel();
	RtlCopyMemory((BYTE*)uAddress,bPush_1,2);
	RtlCopyMemory((BYTE*)(uAddress + 2),bPush_2,5);
	KeLowerIrql(kir);
	WPON();

	return STATUS_SUCCESS;
}
////////////////////////////////////////////////////////////////////////////////
void UnLoadDriver(PDRIVER_OBJECT pDriverObject)
{
	DbgPrint(("DriverUnload\n"));
	UnInstallNtOpenProcessHook();
}
extern "C" NTSTATUS DriverEntry(PDRIVER_OBJECT pDriverObject,PUNICODE_STRING pString)
{
	DbgPrint("Driver Starting...\n");

	DbgPrint("Pass Hook NtOpenProcess...\n");
	InstallNtOpenProcessHook();
	DbgPrint("Pass Hook NtOpenThread...\n");
	InstallNtOpenThreadHook();
	DbgPrint("Pass Hook NtReadVirtualMemory...\n");
	InstallReadVirtualMemoryHook();
	DbgPrint("Pass Hook NtWriteVirtualMemory...\n");
	InstallWriteVirtualMemoryHook();

	pDriverObject->DriverUnload = UnLoadDriver;
	return STATUS_SUCCESS;
}