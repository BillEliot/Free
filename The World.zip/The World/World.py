﻿# -*- coding:utf-8 -*-

from WorldClass import *
 
 #一系列初始化
pygame.init()
Screen = pygame.display.set_mode((694,289))
pygame.display.set_caption("World")
BackGround = pygame.image.load("BG.png")
Time = pygame.time.Clock()

#全局人物ID
ID = 2

#实例化类
#小樱
Sakura = PARENT(Screen,BackGround,"Sakura_Walk_Left.png","Sakura_Walk_Right.png",pygame.Rect(0,0,36,62),pygame.Rect(0,0,33,62))

Sakura.rect.top = 175
Sakura.rect.left = 500
#红发
RedHair = PARENT(Screen,BackGround,"RedHair_Walk_Right.png","RedHair_Walk_Left.png",pygame.Rect(0,0,31,35),pygame.Rect(0,0,31,35))
Alcohol = CHILD(Screen,BackGround,"RedHair_Walk_Right.png","RedHair_Walk_Left.png",pygame.Rect(0,0,31,35),pygame.Rect(0,0,31,35))
Wave = CHILD(Screen,BackGround,"RedHair_Walk_Right.png","RedHair_Walk_Left.png",pygame.Rect(0,0,31,35),pygame.Rect(0,0,31,35))

RedHair.rect.top = 200
RedHair.rect.left = 300
#手鞠
Temari = PARENT(Screen,BackGround,"Temari_Walk_Right.png","Temari_Walk_Left.png",pygame.Rect(345,0,46,66),pygame.Rect(0,0,46,66))
Fun = CHILD(Screen,BackGround,"Temari_Walk_Right.png","Temari_Walk_Left.png",pygame.Rect(0,0,46,66),pygame.Rect(0,0,46,66))

Temari.rect.top = 175
Temari.rect.left = 300
#精灵组
#红发
Group = pygame.sprite.Group()
Group.add(RedHair)

Group_Alcohol = pygame.sprite.Group()
Group_Alcohol.add(Alcohol)

Group_Wave = pygame.sprite.Group()
Group_Wave.add(Wave)
#小樱
Group_Sakura = pygame.sprite.Group()
Group_Sakura.add(Sakura)
#手鞠
Group_Temari = pygame.sprite.Group()
Group_Temari.add(Temari)

Group_Fun = pygame.sprite.Group()
Group_Fun.add(Fun)
#技能频率控制
bFlag_Alcohol = False
nTime_Alcohol = 0

bFlag_Wave = False
nTime_Wave = 0

bAlcoholEnd = False
bWaveEnd = False
#====================
nTime_Fun = 0
bFlag_Fun = False
 #主循环
while True:
    Time.tick(60)
    
    for event in pygame.event.get():
        if event.type == QUIT:
            exit()
    #========================================
    #渲染背景
    Screen.blit(BackGround,(0,0))
    #检测键盘
    Key = pygame.key.get_pressed()
    #P1
    if ID == 1:
        if Key[K_j]:
            bFlag_Alcohol = True
        if Key[K_k]:
            bFlag_Wave = True
        if Key[K_a]:
            RedHair.ImageIndex = 1
            RedHair.Load("RedHair_Walk_Left.png",29,35,9)
            RedHair.rect.left -= 3
            Group.update(pygame.time.get_ticks(),60)
            Group.draw(Screen)    
        if Key[K_d]:
            RedHair.ImageIndex = 0
            RedHair.Load("RedHair_Walk_Right.png",30,35,9)
            RedHair.rect.left += 3
            Group.update(pygame.time.get_ticks(),60)
            Group.draw(Screen)
        
        #P2
        if Key[K_LEFT]:
            Sakura.ImageIndex = 1
            Sakura.Load("Sakura_Walk_Left.png",28,62,5)
            Sakura.rect.left -= 3
            Group_Sakura.update(pygame.time.get_ticks(),60)
            Group_Sakura.draw(Screen)
        if Key[K_RIGHT]:
            Sakura.ImageIndex = 0
            Sakura.Load("Sakura_Walk_Right.png",29,62,5)
            Sakura.rect.left += 3
            Group_Sakura.update(pygame.time.get_ticks(),60)
            Group_Sakura.draw(Screen)
    elif ID == 2:
        if Key[K_j]:
            bFlag_Fun = True
        if Key[K_a]:
            Temari.ImageIndex = 1
            Temari.Load("Temari_Walk_Left.png",48,60,7)
            Temari.rect.left -= 3
            Group_Temari.update(pygame.time.get_ticks(),60)
            Group_Temari.draw(Screen)
        if Key[K_d]:
            Temari.ImageIndex = 0
            Temari.Load("Temari_Walk_Right.png",48.5,60,7)
            Temari.rect.left += 3
            Group_Temari.update(pygame.time.get_ticks(),60)
            Group_Temari.draw(Screen)
    #=========================================================================
    #释放技能——酒碗(红发)
    if bFlag_Alcohol == True:
        nTime_Alcohol += 1
        #加载副技能
        if nTime_Alcohol == 30:
            bFlag_Alcohol = False
            bAlcoholEnd = True
            
            Alcohol.Load("RedHair_Alcohol.png",19,50,6)
            Alcohol.rect.left = RedHair.rect.left + 20
            Alcohol.rect.top = RedHair.rect.top - 10
            
            nTime_Alcohol = 0
        #主技能    
        RedHair.Load("RedHair_Skill_Alcohol.png",28,35,6)
        Group.update(pygame.time.get_ticks(),60)
        Group.draw(Screen)
    #副技能    
    if bAlcoholEnd == True:
        Alcohol.rect.left += 3
        if Alcohol.rect.left >= 694:
            bAlcoholEnd = False
        Group_Alcohol.update(pygame.time.get_ticks(),60)
        Group_Alcohol.draw(Screen)
    #=========================================================================
    #释放技能——冲击波(红发)
    if bFlag_Wave == True:
        nTime_Wave += 1
        #加载副技能
        if nTime_Wave == 30:
            bFlag_Wave = False
            bWaveEnd = True
            
            Wave.Load("RedHair_Skill_WAVE.png",70,94,6)
            Wave.rect.left = RedHair.rect.left + 20
            Wave.rect.top = RedHair.rect.top - 60
            
            nTime_Wave = 0
        #主技能
        RedHair.Load("RedHair_Skill_Wave.png",30,35,7)
        Group.update(pygame.time.get_ticks(),60)
        Group.draw(Screen)
    #副技能
    if bWaveEnd == True:
        Wave.rect.left += 3
        if Wave.rect.left >= 694 or Wave.frame >= 5:
            bWaveEnd = False
        Group_Wave.update(pygame.time.get_ticks(),240)
        Group_Wave.draw(Screen)
    #=========================================================================
    #释放技能——扇子(手鞠)
    if bFlag_Fun == True:
        nTime_Fun += 1
        #加载副技能(无)
        if nTime_Fun == 40:
            bFlag_Fun = False
                
            nTime_Fun = 0
        #主技能
        Temari.Load("Temari_Skill_Fun.png",48,73,4)
        Temari.rect.left += 1
        Group_Temari.update(pygame.time.get_ticks(),100)
        Group_Temari.draw(Screen)
    #副技能
    #无
    
    if ID == 1:
        if (not Key[K_d]) and (not Key[K_a]) and (not Key[K_w]) and (not Key[K_s]) and (bFlag_Alcohol == False) and(bFlag_Wave == False):
            Screen.blit(RedHair.ImageList[RedHair.ImageIndex],RedHair.rect)
        if (not Key[K_LEFT]) and (not Key[K_RIGHT]) and (not Key[K_UP]) and (not Key[K_DOWN]):
            Screen.blit(Sakura.ImageList[Sakura.ImageIndex],Sakura.rect)
    elif ID == 2:
        if (not Key[K_d]) and (not Key[K_a]) and (not Key[K_w]) and (not Key[K_s]) and (bFlag_Fun == False):
            Screen.blit(Temari.ImageList[Temari.ImageIndex],Temari.rect)
    
    pygame.display.update()