﻿# -*- coding:utf-8 -*-

import pygame
from pygame.locals import *

#定义精灵类
class PARENT(pygame.sprite.Sprite):
    #初始化
    def __init__(self,Screen,BackGround,Image_Walk_Right_FileName,Image_Walk_Left_FileName,RECT_Walk_Right,RECT_Walk_Left):
        pygame.sprite.Sprite.__init__(self)
        
        self.ImageList = []
        self.ImageIndex = 0
        
        #Ex
        self.ImageList.append(pygame.image.load(Image_Walk_Right_FileName).subsurface(RECT_Walk_Right))
        self.ImageList.append(pygame.image.load(Image_Walk_Left_FileName).subsurface(RECT_Walk_Left))
        
        self.rect = pygame.Rect(0,0,0,0)
        self.Screen = Screen
        self.BackGround = BackGround
        #动画帧
        self.image = None
        self.frame = 0
        self.first_frame = 0
        self.last_frame = 0
        self.old_frame = -1
        self.last_time = 0
    #======================================
    #加载技能
    def Load(self,SkillImage,Image_Width,Image_Height,columns):
        #加载图片
        
        self.Image_Skill = pygame.image.load(SkillImage)
        self.frame_width = Image_Width
        self.frame_height = Image_Height
        self.columns = columns
        self.last_frame = columns
    #======================================
    #释放技能
    def update(self,current_time,delay = 60):
        if current_time > self.last_time + delay:
            self.frame += 1
            if self.frame > self.last_frame:
                self.frame = self.first_frame
            self.last_time = current_time
        
        if self.frame != self.old_frame:
            frame_x = self.frame * self.frame_width
            frame_y = 0
            self.image = self.Image_Skill.subsurface(pygame.Rect(frame_x,frame_y,self.frame_width,self.frame_height))
            self.old_frame = self.frame
#==============================================================================
#继承精灵类
class CHILD(PARENT):
    def __init__(self,Screen,BackGround,Image_Walk_Right_FileName,Image_Walk_Left_FileName,RECT_Walk_Right ,RECT_Walk_Left):
        PARENT.__init__(self,Screen,BackGround,Image_Walk_Right_FileName,Image_Walk_Left_FileName,RECT_Walk_Right ,RECT_Walk_Left)
    #=======================================
    #重写父类函数——加载技能
    def Load(self,SkillImage,Image_Width,Image_Height,columns):
        self.frame = 0
        
        self.Image_Skill = pygame.image.load(SkillImage)
        self.frame_width = Image_Width
        self.frame_height = Image_Height
        self.columns = columns
        self.last_frame = columns
#==============================================================================
#pygame引擎类
#class Engine(object):    